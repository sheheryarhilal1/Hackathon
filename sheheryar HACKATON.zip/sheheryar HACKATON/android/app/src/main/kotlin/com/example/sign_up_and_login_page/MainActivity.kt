package com.example.sign_up_and_login_page

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
