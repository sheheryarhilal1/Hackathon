import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class CategoryPage extends StatefulWidget {
  const CategoryPage({super.key});

  @override
  _CategoryPageState createState() => _CategoryPageState();
}

class _CategoryPageState extends State<CategoryPage> {
  List<bool> _selected = [false, false, false]; // Track the selection state

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Category"),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Column(
                    children: [
                      SizedBox(height: 15),
                      Container(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(height: 5),
                            Padding(
                              padding: const EdgeInsets.all(15.0),
                              child: Text(
                                "Nike Air Max 270\n\n\Men'shoes\n\n\$290.00",
                                style: TextStyle(
                                    fontSize: 22, color: Colors.white),
                              ),
                            ),
                            SizedBox(
                              width: 65,
                            ),
                            Row(
                              children: [Image.asset("assets/images/shoe.png")],
                            ),
                          ],
                        ),
                        height: 180,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Color.fromARGB(239, 177, 13, 163),
                          borderRadius: BorderRadius.circular(18),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildCard(Icons.food_bank, "Food", 0),
                  _buildCard(Icons.watch, "Watch", 1),
                  _buildCard(Icons.saved_search, "Saved-Search", 2),
                ],
              ),
              SizedBox(
                height: 30,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildCard(Icons.saved_search, "Saved-Search", 2),
                  _buildCard(Icons.watch, "Watch", 1),
                  _buildCard(Icons.food_bank, "Food", 0),
                ],
              ),
              SizedBox(
                height: 70,
              ),
              Row(
                children: [
                  Container(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Icon(
                          Icons.home,
                          color: Color.fromARGB(239, 177, 13, 163),
                        ),
                        Row(
                          children: [
                            Icon(
                              Icons.favorite,
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Icon(
                              Icons.shopping_cart,
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Icon(
                              Icons.person,
                            ),
                          ],
                        ),
                      ],
                    ),
                    width: 470,
                    height: 45,
                    color: Colors.white,
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCard(IconData icon, String label, int index) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _selected[index] = !_selected[index];
        });
      },
      child: Card(
        color:
            _selected[index] ? Color.fromARGB(239, 177, 13, 163) : Colors.white,
        child: Container(
          width: 100,
          height: 100,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 40),
              SizedBox(height: 10),
              Text(label),
            ],
          ),
        ),
      ),
    );
  }
}
